import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gifs-page',
  templateUrl: './gifs-page.component.html',
  styles: [
  ]
})
export class GifsPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
